function varargout = main(varargin)
% MAIN MATLAB code for main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
% 
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main

% Last Modified by GUIDE v2.5 28-Nov-2020 17:37:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_OpeningFcn, ...
                   'gui_OutputFcn',  @main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[fname,pname,index] = uigetfile({'*.jpg';'*.bmp'},'ѡ��ͼƬ');

    str = [pname fname];
    Img= imread(str);
    axes(handles.axes1);
    imshow(Img);
    title('�����ͼ��')
    save Img;

% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
[fname,pname,index] = uigetfile({'*.jpg';'*.bmp'},'ѡ��ͼƬ');

    str = [pname fname];
    Img= imread(str);
    axes(handles.axes6);
    imshow(Img);
    title('��׼ͼ��')
    save Img;
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
load Img
I1=rgb2gray(Img);%ת��Ϊ�Ҷ�ͼ�� 

fmax1=double(max(max(I1))); %egray�����ֵ�����˫������
fmin1=double(min(min(I1))); %egray����Сֵ�����˫������ 
level=(fmax1-(fmax1-fmin1)/1.5)/255;
bw22=im2bw(I1,level);       %ת��ͼ��Ϊ������ͼ�� 
I2=double(bw22);  
axes(handles.axes2);
imshow(I2),title('�����ͼ���ֵ��');  %�õ���ֵͼ��
I3=bwareaopen(I2,50);%ȥ�����ŻҶ�ֵС��50�Ĳ���
axes(handles.axes3);
imshow(I3),title('�������̬�˲���ͼ��');

I4=imfill(I3,'holes');
axes(handles.axes4);imshow(I4),title('����ͼ��');
PX1=0;
 PX2=0;
 x=0;y=0;z=0;X1=0;Y1=0;
[y,x,z]=size(I4);
I5=double(I4);  
Y1=zeros(y,1);  
for i=1:y     
    for j=1:x  
        if(I5(i,j,1)==1)  
            Y1(i,1)= Y1(i,1)+1;  
        end  
    end 
     if(Y1(i,1)>1)
         PY1=i;
     end
end 
for i=y:-1:1     
    for j=1:x  
        if(I5(i,j,1)==1)  
            Y1(i,1)= Y1(i,1)+1;  
        end  
    end 
     if(Y1(i,1)>1)
         PY2=i;
     end
end 
X1=zeros(1,x);  
for j=1:x     
    for i=1:y  
        if(I5(i,j,1)==1)  
            X1(1,j)= X1(1,j)+1;  
        end  
    end 
     if(X1(1,j)>1)
         PX1=j;
         break
     end
end 
for j=x:-1:1      
    for i=1:y  
        if(I5(i,j,1)==1)  
            X1(1,j)= X1(1,j)+1;  
        end  
    end 
     if(X1(1,j)>1)
         PX2=j;break
     end
end 
 I6=I3(PY2:PY1,PX1:PX2,:);
 I6s=Img(PY2:PY1,PX1:PX2,:);
 
axes(handles.axes5);imshow(I6),title('��λ���к��ͼ��');%��Ϊ���㻷���Ĳ�ͬ���������ͼ��Ĵ�С��һ��λ��Ҳ��ͬ
save I6;
%���Զ�Ŀ��ͼ��λ���е�ԭ����ҪΪ����������׼��
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
msgbox('ͬ��һ��һ������������Ҫ����ϵѧ��Q2869939756')
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
load I6;
load I61;
[y,x]=size(I61);
I6=imresize(I6,[y,x]);%΢����������ͼ��ͬ��С
I6s=imresize(I6s,[y,x]);%΢����������ͼ��ͬ��С
I7=I6-I61;
axes(handles.axes11);imshow(I7),title('�����ͼ��');
I8=bwareaopen(I7,50);%ȥ�����ŻҶ�ֵС��50�Ĳ���
axes(handles.axes12);imshow(I8),title('��׼ͼ����̬�˲���');

se=strel('rectangle',[25,25]);  %���νṹԪ�� 
I9=imclose(I8,se);%�Ի���ͼ����ࡢ���ͼ��Ŀ����Ϊ��ǿ������
axes(handles.axes13);imshow(I9),title('���۱�����');
msgbox('ʱ��ִ٣�����Ҫ����ϵѧ��Q2869939756')
    
    





%position[a,b,c,d][a,b]�ǻ�ͼ��������µ�����꣬c,d�ǸߺͿ���
%'Curvature'�߿�'LineWidth'���ͣ���ɫr

% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
clc;
close all;
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
